
READ THIS FOR THE TEST CASES:

1 - ilk okunan instruction sistem dizaynı neticesiyle ikinci memoryden başlıyor.
2 - instruction codes
lw - 110001
sw - 110101
beq - 001000
bitzal - 100010
add - 100000 
sub - 100010
AND - 100100
OR -  100101
set - 101010


OP rd, rs, rt

opcode 	rs 	rt 	rd 	shift (shamt) 	funct
6 bits 	5 bits 	5 bits 	5 bits 	5 bits 	6 bits 